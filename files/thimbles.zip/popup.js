var page_title = document.title;
var choiceBall = 1;
	window.onload = function(){
				
		document.onclick = ({target}) => {
			page_title = document.title;
			$(".thimbles-game.thimbles__game").attr('id','id_xThimbles_game');
			if (page_title.indexOf('Наперстки') !== -1 || page_title.indexOf('Thimbles') !== -1)
			{
				let parent = target;
				clas_name_parent = parent.parentNode.className;
				if (target.id == "button-game-start" )
				{
					$("#thimbles-hack").remove();
					
					let buttonS = $(".thimbles-choice-btn--is-not-active.thimbles-choice__btn.thimbles-choice-btn .thimbles-choice-btn__text").text();
					if (buttonS == '')
					{
						buttonS = $(".thimbles-panel-choice__btn.thimbles-choice-btn.thimbles-choice-btn--is-active .thimbles-choice-btn__text").text();
						
						if (buttonS[0] == 1)
							buttonS = '2';
						else
							buttonS = '1';
					}
					setTimeout(function () 
					{
						if (buttonS[0] == 1)
							makeid(2);
						else
							makeid(1);
					}, 2500); 
				}
				
				
/*
				if (target.className == 'thimbles-choice-btn__text' ||
					target.className == 'thimbles__choice thimbles-choice' ||
					target.className == 'thimbles-choice-btn--is-active thimbles-choice__btn thimbles-choice-btn'
				)
				{
					// thimbles-choice-btn__text
					console.log(target);
					
					if (choiceBall == 1)
						choiceBall = 2;
					else
						choiceBall = 1;
					
					
					console.log(choiceBall);
				}*/
			}
        }
    };
	
	function calculateX(n) {
		if (n < 500) return 0;
		if (n > 1300) return 300;
		return ((n - 500) / (1300 - 500)) * 300;
	}
	
	function makeid(type)
	{
		let hemlBolds = '<div id="thimbles-hack" style="position: fixed;top: 80px;left: 0;width: 100%;height: 100%;display: flex;justify-content: center;align-items: center;pointer-events: none;">';
		
		const clientWidth = document.documentElement.clientWidth;
		
		let marginMax = 170;
		
		marginMax += calculateX(clientWidth);
		
		
		if (type == 1)
		{
			let getResult = getIndexNumber();
			if (getResult == 0)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-right: '+marginMax+'px; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-right: '+marginMax+'px; opacity: 0">';
			
			if (getResult == 1)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; opacity: 0">';
			
			if (getResult == 2)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-left: '+marginMax+'px; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-left: '+marginMax+'px; opacity: 0">';
		}
		else
		{
			let getResult = getIndexUniquePair();
			if (getResult[0] == 0)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-right: '+marginMax+'px; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-right: '+marginMax+'px; opacity: 0">';
			
			if (getResult[0] == 1 || getResult[1] == 1)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; opacity: 0">';
			
			if (getResult[1] == 2)
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-left: '+marginMax+'px; opacity: .7">';
			else
				hemlBolds += '<img src="https://i.postimg.cc/T3cNJXmL/ball.png" style="position: absolute;margin-bottom: 120px; max-width: 100%;max-height: 100%;pointer-events: none; margin-left: '+marginMax+'px; opacity: 0">';
		}
		
		
		hemlBolds += '</div>';
		$('#info-block').after(hemlBolds);
		
		
	}

function getIndexNumber() {
	
    const a = Math.PI * 42 / 7;
    const b = a - 18.84955592153876;
    const c = Date.now() % 1000;
    const d = (c * b) % 3;
    const e = Math.floor(Math.abs(d));
    const f = e % 3;
    const g = f * 1.0000001;
    const h = Math.round(g);
    const i = h & 3;
    const j = i ^ 0;
    const k = j | 0;
    const l = k << 0;
    const m = l >>> 0;
    const n = m + 0;
    const o = n - 0;
    const p = o * 1;
    const q = p / 1;
    const r = q % 3;
    const s = Math.floor(Math.random() * 3);
    return s;
}


function getIndexUniquePair() {
    const x = Math.E * 10;
    const y = x / 2.718281828459045;
    const z = Date.now() % 1000;
    const w = (z * y) % 3;
    const v = ((z + 123) * x) % 3;
    let u = Math.floor(Math.abs(w)) % 3;
    let t = Math.floor(Math.abs(v)) % 3;
    while (u === t) {
        t = (t + 1) % 3;
    }
    const s = [u, t];
    const r = s.map((n) => n + 0);
    const q = r.filter((n) => n >= 0);
    const pz = q.slice(0, 2);
    const o = pz.concat([]);
    const n = o.reverse().reverse();
    const m = n.sort(() => 0);
    const l = m.map((n) => n * 1);
    const k = l.filter((n) => n < 3);
    const j = k.reduce((a, b) => [a, b], []);
    const i = j.flat();
    const h = i.slice(0, 2);
    const g = h.sort(() => Math.random() - 0.5);
    const f = g.map((n) => n | 0);
    const e = f.filter((n) => n !== null);
    const d = e.concat([]);
    const c = d.reverse();
    const b = c.slice(0, 2);
    const a = b.sort(() => 0);
    const p = [[0, 1], [1, 2], [0, 2]];
    const ind = Math.floor(Math.random() * p.length);
    return p[ind];
}

