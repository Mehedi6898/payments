var string_id = 1231414;
var page_title = document.title;
index_max = 0;
function sender_cheker(min, max) 
{
	return Math.floor(Math.random() * (max - min + 1)) + min;
}


    window.onload = function() {
	
		document.onclick = ({target}) => {
		
		page_title = document.title;
		if (page_title.indexOf('Wild West Gold') !== -1)
		{
			let parent = target;
			console.log(parent.className);
			if (parent.className == "gow-btn-mid__val" || parent.className == 'dont_touch gow-start-btn gow-btn gow-btn-green gow-btn-mid our-btn'
			|| parent.className == 'gow-btn gow-btn--green gow-btn-play gow-box__btn gow-box__btn--play show-btn-leave-from show-btn-leave-active'
			|| parent.tagName == 'use' || parent.className == 'gow-btn__text' || parent.className == 'gow-btn gow-btn--green gow-modal-bet__btn')
			{
				index_max = 0;
				get_format_new();
				get_format();
			}
			
			if (parent.className == "gow-btn-popup__val")
			{
				get_format_new();
			}
			
			if (parent.className == 'gow-game-cel' || parent.className == 'gow-game__cel')
			{
				index_max ++;
				get_format();
			}
		}}};

//   
function getinfont(min, max) {min = Math.ceil(min);max = Math.floor(max);return_tt = Math.floor(Math.random() * (max - min)) + min;return return_tt;}
function get_format() {
	  try {
	  if ($('div[class="gow-game-row"]').eq(0).children('button[class="gow-game-cel"]').length == 2) 
	  {
			// Если в первой строке игры 2 ячейки class="gow-game-row"
		  let get_infont = getinfont(0, 2);
		  $('div[class="gow-game-row"]').eq(9 - index_max).children('button').eq(get_infont).attr("style", 'background:url(https://v2l.cdnsfree.com/default/img/gold_of_west/gow-win-img.jpg)');
	  }
	  if ($('div[class="gow-game-row"]').eq(0).children('button[class="gow-game-cel"]').length == 3) 
	  {
		// Если в первой строке игры не 2 ячейки (вероятно, 3)
		  let get_infont = getinfont(0, 3);
		  $('div[class="gow-game-row"]').eq(9 - index_max).children('button').eq(get_infont).attr("style", 'background:url(https://v2l.cdnsfree.com/default/img/gold_of_west/gow-win-img.jpg)');
	  }
	} catch (error) {

	}
	
  
  
  try {
	  if ($('div[class="gow-game__row"]').eq(0).children('button[class="gow-game__cel"]').length == 2) 
	  {
			// Если в первой строке игры 2 ячейки class="gow-game-row"
		  let get_infont = getinfont(0, 2);
		  $('div[class="gow-game__row"]').eq(9 - index_max).children('button').eq(get_infont).attr("style", 'background:url(https://v2l.cdnsfree.com/default/img/gold_of_west/gow-win-img.jpg)');
	  }
	  if ($('div[class="gow-game__row"]').eq(0).children('button[class="gow-game__cel"]').length == 3) 
	  {
		// Если в первой строке игры не 2 ячейки (вероятно, 3)
		  let get_infont = getinfont(0, 3);
		  $('div[class="gow-game__row"]').eq(9 - index_max).children('button').eq(get_infont).attr("style", 'background:url(https://v2l.cdnsfree.com/default/img/gold_of_west/gow-win-img.jpg)');
	  }
	} catch (error) {

	}
  
  
}

function get_format_new(){
	 // Проверяем, что элементы с классом gow-game-cel существуют
	  let $elements = $('button[class="gow-game-cel"]');
	
	try {
	  if ($elements.length > 0) {
		// Если элементы найдены, применяем стиль
		$elements.attr("style",'');
	  }
	} catch (error) {

	}
	
	  try {
	 $elements = $('button[class="gow-game__cel"]');
	  if ($elements.length > 0) {
		// Если элементы найдены, применяем стиль
		$elements.attr("style",'');
	  }
	} catch (error) {

	}
	  
}