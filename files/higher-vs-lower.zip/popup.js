var string_id    = 1231414;
var page_title   = document.title;
 var time_cklick  = 0;
var check_button = 0;

	
window.onload = function() {
	var page_title = document.title;
	
	document.onclick = ({target}) => {
		page_title   = document.title;
		if (page_title.indexOf('Higher vs Lower') !== -1)
		{
			let parent = target;
			console.log(parent.className);
			if (parent.className == "button-game-start hilo-controls__play")
				get_format();
			
			if (parent.className == "hilo-makes-btn__text")
				divDelete();
		}
	}
};



function getinfont(min, max) {min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min)) + min;
}


function get_format()
{
	let number = getinfont(1,99);
	
	let hemlBolds = '<div id="divForPrintResilt" style="max-width: 100%;left: 130px;top: -29px;position: relative;max-height: 100%;pointer-events: none;display: inline-block; ">';
	hemlBolds += '<img src="https://s.iimg.su/s/11/Mrse3g5Rign7qBNHXEvlTP75ZFoxDksy67fNPW82.png" >';
	hemlBolds += '<div style="opacity: .5;position: absolute; top: 50%;left: 50%;transform: translate(-50%, -50%); color: white; font-size: 50px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);">'+String(number)+'</div></div>';
	
	
	$('.hilo-helper.hilo__helper').after(hemlBolds);
}


function divDelete()
{
	$('#divForPrintResilt').remove();
}